# UnitySDK
This is the Unity SDK for 3Glasses Devices.

## version: v6.0.0

**This repository is Unity3D project**

### Quick Start
  1. download latest releases zip
  2. unzip the zip file
  3. use Unity3D open this project
